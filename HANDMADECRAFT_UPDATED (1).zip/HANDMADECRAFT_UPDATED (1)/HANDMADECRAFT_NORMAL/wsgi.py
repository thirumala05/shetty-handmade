"""Production entrypoint.

Run with a WSGI server, e.g.:
    gunicorn wsgi:app --bind 0.0.0.0:$PORT
"""
from app import app

if __name__ == "__main__":
    app.run()
